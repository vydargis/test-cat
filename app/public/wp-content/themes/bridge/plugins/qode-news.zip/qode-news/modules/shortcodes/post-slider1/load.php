<?php

include_once QODE_NEWS_SHORTCODES_PATH.'/post-slider1/functions.php';
include_once QODE_NEWS_SHORTCODES_PATH.'/post-slider1/post-slider1.php';