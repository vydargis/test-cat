<?php if( function_exists('qode_like') ) {
    ?>
    <div class="qode-ls-header-info qode-ls-like">
        <?php qode_like(); ?>
    </div>
<?php } ?>