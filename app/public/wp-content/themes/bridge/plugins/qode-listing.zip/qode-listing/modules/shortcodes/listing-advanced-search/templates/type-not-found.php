<p class="qode-ls-type-not-found">
    <?php esc_html_e( 'You need to select Listing type.', 'qode-listing' ); ?>
</p>